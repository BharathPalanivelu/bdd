package org.cap.pilot.rest.service;

import java.util.List;

import org.cap.pilot.rest.model.Pilot;

public interface PilotService {
	public void save(Pilot pilot);
	public List<Pilot> getAll();
	public void delete(Integer pilotId) ;
}
