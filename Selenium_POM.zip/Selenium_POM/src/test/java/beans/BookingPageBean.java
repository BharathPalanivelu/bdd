package beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BookingPageBean {
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(id="txtEmail")
	private WebElement email;
	
	@FindBy(id="btnConfirm")
	private WebElement confirmBookingBtn;
	
	private WebDriver driver;
	
	public BookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public String getFirstName() {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setConfirmBookingBtn() {
		this.confirmBookingBtn.click();
	}
	
	
	public void assignValues(String lastName,String firstName,String email) {
		setFirstName(firstName);
		setLastName(lastName);
		setEmail(email);
	}
	

}
