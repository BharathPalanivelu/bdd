package org.cap.model;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

public class Pilot {
	@Range(min=1000,max=10000,message="* PilotId should be between 1000 and 10000.")
	private int pilotId;
	@NotEmpty(message="* Please enter firstName.")
	private String firstName;
	private String lastName;
	private String address;
	private String gender;
	private boolean isCertified;
	private double maxCrusingRange;
	
	@Email(message="* Please enter valid Email Id.")
	@NotEmpty(message="* please enter Email Id.")
	private String email;
	
	@Min(value=100000,message="* Salary min should be 1Lak.")
	private double salary;
	
	@Future(message=" * Date of Joining should be Future Date.")
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	private Date dateOfJoining;
	
	private String city;
	
	
	
	public Pilot(int pilotId, String firstName, String lastName, String address, String gender, boolean isCertified,
			double maxCrusingRange, double salary, Date dateOfJoining, String city) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.isCertified = isCertified;
		this.maxCrusingRange = maxCrusingRange;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
		this.city = city;
	}


	public Pilot() {
		
		
	}
	
	
	public Pilot(int pilotId, String firstName, String lastName, String address, String gender, boolean isCertified,
			double maxCrusingRange, double salary, Date dateOfJoining) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.isCertified = isCertified;
		this.maxCrusingRange = maxCrusingRange;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
	}
	
	
	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public boolean isCertified() {
		return isCertified;
	}


	public void setCertified(boolean isCertified) {
		this.isCertified = isCertified;
	}


	public double getMaxCrusingRange() {
		return maxCrusingRange;
	}
	public void setMaxCrusingRange(double maxCrusingRange) {
		this.maxCrusingRange = maxCrusingRange;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}


	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gender=" + gender + ", isCertified=" + isCertified + ", maxCrusingRange="
				+ maxCrusingRange + ", email=" + email + ", salary=" + salary + ", dateOfJoining=" + dateOfJoining
				+ ", city=" + city + ", getEmail()=" + getEmail() + ", getCity()=" + getCity() + ", getPilotId()="
				+ getPilotId() + ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName()
				+ ", getAddress()=" + getAddress() + ", getGender()=" + getGender() + ", isCertified()=" + isCertified()
				+ ", getMaxCrusingRange()=" + getMaxCrusingRange() + ", getSalary()=" + getSalary()
				+ ", getDateOfJoining()=" + getDateOfJoining() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}


	
	
	

}
