package login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.LoginPageBean;
import bean.MainPageBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private LoginPageBean loginPageBean;
	private MainPageBean mainPageBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\vidavid\\selenium\\chromedriver\\chromedriver.exe");
		
		webdriver=new ChromeDriver();
		loginPageBean=new LoginPageBean(webdriver);
		mainPageBean=new MainPageBean(webdriver);
	}
	
	@Given("^Open CapgBanking login page$")
	public void open_CapgBanking_login_page() throws Throwable {
		 webdriver.get("http://localhost:8080/CapgBanking/");
		 
		 assertEquals("CapgBanking", loginPageBean.getPageHeading());
		 Thread.sleep(1000);
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
	  loginPageBean.setUserName("tom@gmail.com");
	  loginPageBean.setUserpassword("tom123jerry");
	  Thread.sleep(1000);
	}

	@When("^Submit validate login details$")
	public void submit_validate_login_details() throws Throwable {
		 loginPageBean.onSubmit_navigate_to_mainPage();
		 Thread.sleep(1000);
	}

	@Then("^navigate to MainPage$")
	public void navigate_to_MainPage() throws Throwable {
	   assertEquals("Hello!tom", mainPageBean.getGreetUser());
	   Thread.sleep(1000);
	}
	
	@After
	public void tearDown() {
		webdriver.close();
	}


}
