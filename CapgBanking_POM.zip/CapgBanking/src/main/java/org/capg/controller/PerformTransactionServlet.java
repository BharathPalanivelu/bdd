package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/PerformTransactionServlet")
public class PerformTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
	
		List<Account> accounts= loginService.getAllAccounts(custId);
		
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<head>"
				+ "<title>CapgBanking</title>\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"styles/mainStyles.css\">"
				+
				"</head>"
				+ "<body>\r\n" + 
				"<form action='#' method='post'>" + 
				"<div id=\"depwith\">\r\n"
				+ "<table cellspacing=10>"
				+ "<tr><th colspan=3>"
				+ " Deposit Or Withdrawal Operation" 
				+ "</th></tr>"
				+ "<tr>"
				+ "<td>Choose Account Number:</td>"
				+ "<td><select name=\"accountNo\">");
		for(Account account:accounts) {
			out.println("<option value=\"" + account.getAccountNumber()  +"\">"+account.getAccountNumber()+"-"+
						account.getAccountType()+"</option>");
		}
				
				out.println("</select>"
				+ "</td></tr>"
				+ "<tr>"
				+ "<td>Choose Operation:</td>"
				+ "<td>"
				+ "<input type='radio' name='transtype' value='debit'>Withdrawal"
				+ "<input type='radio' name='transtype' value='credit'>Deposit"
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Amount:</td>"
				+ "<td>"
				+ "<input type='text' name='amount' size='20'>"
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Description:</td>"
				+ "<td>"
				+ "<input type='text' name='description' size='20'>"
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' class='btnStyle' value='Do Transaction'>"
				+ "</td>"
				+ "</tr>"+
				
				
				"</table>"+
				"</div>\r\n" + 
				"\r\n"
				+ "</form>" + 
				"</body>"
				
				+ "</html>");
		
			
	
	}

}
