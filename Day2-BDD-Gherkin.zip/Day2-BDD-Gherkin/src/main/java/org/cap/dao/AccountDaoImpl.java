package org.cap.dao;

import org.cap.model.Account;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public boolean createAccount(Account account) {
		
		return true;
	}

}
