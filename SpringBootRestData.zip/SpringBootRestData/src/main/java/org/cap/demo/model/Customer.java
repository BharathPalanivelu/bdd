package org.cap.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer",
	"handler","created","updated","createdBy","lastUpdatedBy"})
/*@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,
property="customerId")*/
public class Customer {
	@Id
	private int customerId;
	private String customerName;
	
	
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnoreProperties("customers")
	@JoinTable(name="products_customers",
		joinColumns= {@JoinColumn(name="customers")},
		inverseJoinColumns= {@JoinColumn(name="products")})
	//@JsonBackReference
	private List<Product> products=new ArrayList<>();
	
	public Customer() {
		
	}
	
	public Customer(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	
	
	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	
	
	

}
