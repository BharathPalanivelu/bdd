package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestDataApplication.class, args);
	}
}
