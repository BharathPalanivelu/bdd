package booking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import beans.BookingPageBean;
import beans.SuccessPageBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private BookingPageBean bookingPageBean;
	private SuccessPageBean successPageBean;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", 
				"C:\\vidavid\\selenium\\chromedriver\\chromedriver.exe");
		
		webdriver=new ChromeDriver();
		this.bookingPageBean=new BookingPageBean(webdriver);
		this.successPageBean=new SuccessPageBean(webdriver);
		
	}
	
	@Given("^Open booking Page$")
	public void open_booking_Page() throws Throwable {
	   webdriver.get("C:/Users/vidavid/Desktop/hotelBooking/hotelbooking.html");
	}

	@Given("^Provide valid booking details$")
	public void provide_valid_booking_details() throws Throwable {
		bookingPageBean.assignValues("tom", "jerry", "tom@gmail.com");
	}

	@When("^Sumit Confirm Booking Button$")
	public void sumit_Confirm_Booking_Button() throws Throwable {
	    bookingPageBean.setConfirmBookingBtn();
	}

	@Then("^Navigate to successPage$")
	public void navigate_to_successPage() throws Throwable {
	   assertEquals("Booking Completed!", successPageBean.getMessage());
	}



}
