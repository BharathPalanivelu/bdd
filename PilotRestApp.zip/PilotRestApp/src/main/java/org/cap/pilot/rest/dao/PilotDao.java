package org.cap.pilot.rest.dao;

import java.util.List;

import org.cap.pilot.rest.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public interface PilotDao extends JpaRepository<Pilot,Integer> {
	

}
