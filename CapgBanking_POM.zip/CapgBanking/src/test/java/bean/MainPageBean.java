package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class MainPageBean {
	
	private String greetUser;
	private WebDriver driver;
	
	public MainPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String getGreetUser() {
		return driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div[1]")).getText();
	}

	public void setGreetUser(String greetUser) {
		
		this.greetUser = greetUser;
	}
	
	

}
