package org.cap.dao;

import org.cap.model.Account;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public boolean createAccount(Account account) {
		
		return true;
	}

	@Override
	public Account findAccount(int accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
