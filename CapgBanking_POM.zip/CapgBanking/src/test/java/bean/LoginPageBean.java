package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {


	
	private String pageHeading;
	
	
	private String userName;
	private String userpassword;
	private String submitBtn;
	
	private WebDriver driver;
	
	
	
	public LoginPageBean() {
		
	}
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	public LoginPageBean(String pageHeading, String userName, String userpassword, String submitBtn) {
		super();
		this.pageHeading = pageHeading;
		this.userName = userName;
		this.userpassword = userpassword;
		this.submitBtn = submitBtn;
	}
	public String getPageHeading() {
		
		
		return driver.findElement(By.tagName("h1")).getText();
	}
	public void setPageHeading(String pageHeading) {
		
		
		this.pageHeading = pageHeading;
	}
	public String getUserName() {
		
		
		return userName;
	}
	public void setUserName(String userName) {
		driver.findElement(By.name("userName")).sendKeys(userName);
		
		this.userName = userName;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		
		driver.findElement(By.name("userPwd")).sendKeys(userpassword);
		
		this.userpassword = userpassword;
	}
	public String getSubmitBtn() {
		return submitBtn;
	}
	public void setSubmitBtn(String submitBtn) {
		this.submitBtn = submitBtn;
	}
	
	
	public void onSubmit_navigate_to_mainPage() {
		
		/*setUserName(userName);
		setUserpassword(usrpassword);*/
		
		driver.findElement(By.name("login")).submit();
	}
	
	
	
}
