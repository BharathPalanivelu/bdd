package org.cap.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Pilot {
	
	@Id
	@GeneratedValue
	private int pilotId;
	
	private String firstName;
	private String lastName;
	private boolean isCertified;
	private double maxCrusingRange;
	private double salary;
	
	
	private Date dateOfJoining;

	
	

	public Pilot(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}


	public int getPilotId() {
		return pilotId;
	}


	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public boolean isCertified() {
		return isCertified;
	}


	public void setCertified(boolean isCertified) {
		this.isCertified = isCertified;
	}


	public double getMaxCrusingRange() {
		return maxCrusingRange;
	}


	public void setMaxCrusingRange(double maxCrusingRange) {
		this.maxCrusingRange = maxCrusingRange;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public Date getDateOfJoining() {
		return dateOfJoining;
	}


	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public Pilot() {
		
	}
	
	
	public Pilot(int pilotId, String firstName, String lastName, boolean isCertified, double maxCrusingRange,
			double salary, Date dateOfJoining) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.isCertified = isCertified;
		this.maxCrusingRange = maxCrusingRange;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
	}


	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", isCertified="
				+ isCertified + ", maxCrusingRange=" + maxCrusingRange + ", salary=" + salary + ", dateOfJoining="
				+ dateOfJoining + "]";
	}
	
	

}
